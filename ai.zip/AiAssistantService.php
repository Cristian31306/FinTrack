<?php

namespace App\Services\Ai;

use App\Models\Category;
use App\Models\CreditCard;
use App\Models\User;
use App\Models\ResponsiblePerson;
use App\Models\CardPayment;
use App\Models\Cut;
use App\Services\Fintrack\DebtSummaryService;
use App\Services\Fintrack\PurchaseService;
use App\Services\Fintrack\CutService;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;

class AiAssistantService
{
    protected string $baseUrl    = 'https://api.groq.com/openai/v1/chat/completions';
    protected string $textModel  = 'llama-3.3-70b-versatile';
    protected string $visionModel = 'llama-3.2-11b-vision-preview';

    // Palabras que indican confirmación explícita del usuario
    private const CONFIRM_TRIGGERS = [
        'si', 'sí', 'dale', 'ok', 'okay', 'confirmado', 'confirmo',
        'registrar', 'procede', 'págalo', 'hágale', 'adelante',
        'listo', 'perfecto', 'correcto', 'exacto', 'guardar',
    ];

    // Tiempo de vida del registro pendiente en caché (minutos)
    private const CACHE_TTL_MINUTES = 10;

    public function __construct(
        protected PurchaseService    $purchaseService,
        protected DebtSummaryService $summaryService,
        protected CutService         $cutService,
    ) {}

    // =========================================================================
    // PUNTO DE ENTRADA PRINCIPAL
    // =========================================================================

    public function chat(User $user, string $message, array $history = [], ?array $image = null, bool $isWhatsApp = false): string
    {
        $context      = $this->buildUserContext($user);
        $systemPrompt = $this->buildSystemPrompt($user->name, $context);

        $messages = [['role' => 'system', 'content' => $systemPrompt]];
        $messages = array_merge($messages, $this->reconstructHistory($history));

        if ($image) {
            $messages[] = ['role' => 'user', 'content' => $message];
            return $this->chatWithVision($messages, $message, $image, $isWhatsApp);
        }

        $messages[] = ['role' => 'user', 'content' => $message];

        return $this->callGroq($messages, $user, $context, $message, $isWhatsApp);
    }

    // =========================================================================
    // LLAMADA AL LLM
    // =========================================================================

    private function callGroq(array $messages, User $user, array $context, string $rawMessage, bool $isWhatsApp): string
    {
        $isConfirm = $this->isConfirmationMessage($rawMessage);

        $toolChoice = 'auto';
        if ($isConfirm) {
            if (Cache::has($this->cacheKey($user))) {
                $toolChoice = ['type' => 'function', 'function' => ['name' => 'create_purchase']];
            } elseif (Cache::has("fintrack_pending_category_{$user->id}")) {
                $toolChoice = ['type' => 'function', 'function' => ['name' => 'create_category']];
            } elseif (Cache::has("fintrack_pending_responsible_{$user->id}")) {
                $toolChoice = ['type' => 'function', 'function' => ['name' => 'create_responsible']];
            } elseif (Cache::has("fintrack_pending_payment_{$user->id}")) {
                $toolChoice = ['type' => 'function', 'function' => ['name' => 'create_payment']];
            }
        }

        $payload = [
            'model'       => $this->textModel,
            'messages'    => $messages,
            'tools'       => $this->getToolsDefinition(),
            'tool_choice' => $toolChoice,
            'temperature' => 0.3,   // Más bajo = más determinista para function calling
            'max_tokens'  => 1024,
        ];

        try {
            $response = Http::withoutVerifying()
                ->withHeaders(['Authorization' => 'Bearer ' . config('services.groq.key')])
                ->post($this->baseUrl, $payload);

            if ($response->failed()) {
                Log::error('[FinTrack AI] Groq HTTP error', [
                    'status' => $response->status(),
                    'body'   => $response->body(),
                ]);
                return "Lo siento, tuve un problema de comunicación (código {$response->status()}). Intenta de nuevo.";
            }

            $choice = $response->json('choices.0.message');

            if (empty($choice)) {
                return "No obtuve una respuesta válida. Por favor intenta de nuevo.";
            }

            // ── Function calling ──────────────────────────────────────────────
            if (!empty($choice['tool_calls'])) {
                $call     = $choice['tool_calls'][0];
                $funcName = $call['function']['name'];
                $args     = json_decode($call['function']['arguments'], true) ?? [];

                return match ($funcName) {
                    'prepare_purchase'    => $this->handlePrepare($args, $user, $context, $isWhatsApp),
                    'create_purchase'     => $this->handleExecute($user, $isWhatsApp),
                    'prepare_category'    => $this->handlePrepareCategory($args, $user, $isWhatsApp),
                    'create_category'     => $this->handleExecuteCategory($user, $isWhatsApp),
                    'prepare_responsible' => $this->handlePrepareResponsible($args, $user, $isWhatsApp),
                    'create_responsible'  => $this->handleExecuteResponsible($user, $isWhatsApp),
                    'prepare_payment'     => $this->handlePreparePayment($args, $user, $context, $isWhatsApp),
                    'create_payment'      => $this->handleExecutePayment($user, $isWhatsApp),
                    default               => "Función desconocida: {$funcName}.",
                };
            }

            // ── Respuesta de texto normal ─────────────────────────────────────
            $response = $choice['content'] ?? "Entendido, ¿en qué más te puedo ayudar?";
            return $isWhatsApp ? $this->formatForWhatsApp($response) : Str::markdown($response);

        } catch (\Exception $e) {
            Log::error('[FinTrack AI] Excepción en callGroq', ['error' => $e->getMessage()]);
            return "Ocurrió un error interno. Por favor intenta de nuevo.";
        }
    }

    // =========================================================================
    // PASO 1 — VISTA PREVIA (no persiste en BD)
    // =========================================================================

    private function handlePrepare(array $args, User $user, array $context, bool $isWhatsApp): string
    {
        // ── Validaciones básicas ──────────────────────────────────────────────
        $name   = trim($args['name'] ?? '');
        $amount = (float) ($args['total_amount'] ?? 0);

        if (strlen($name) < 2) {
            return "Necesito una descripción más clara del gasto. ¿Cómo lo llamo?";
        }
        if ($amount <= 0) {
            return "Necesito el monto exacto del gasto para continuar.";
        }

        // ── Resolución semántica de categoría ────────────────────────────────
        $args = $this->resolveCategory($args, $context);

        // ── Resolución de tarjeta ─────────────────────────────────────────────
        $args = $this->resolveCard($args, $context);

        // ── Resolución de fecha ───────────────────────────────────────────────
        $args['purchase_date'] = $this->resolveDate($args['purchase_date'] ?? null);

        // ── Guardar en caché (sin tocar la BD) ───────────────────────────────
        Cache::put(
            $this->cacheKey($user),
            $args,
            now()->addMinutes(self::CACHE_TTL_MINUTES)
        );

        // ── Construir vista previa ────────────────────────────────────────────
        return $this->buildPreviewMarkdown($args, $amount, $isWhatsApp);
    }

    // =========================================================================
    // PASO 2 — REGISTRO DEFINITIVO (lee desde caché, escribe en BD)
    // =========================================================================

    private function handleExecute(User $user, bool $isWhatsApp): string
    {
        $pending = Cache::get($this->cacheKey($user));

        if (!$pending) {
            return "❌ La sesión de confirmación expiró (" . self::CACHE_TTL_MINUTES . " min). ¿Me cuentas de nuevo qué quieres registrar?";
        }

        try {
            $purchase = $this->purchaseService->create([
                'name'               => $pending['name'],
                'total_amount'       => $pending['total_amount'],
                'purchase_date'      => $pending['purchase_date'],
                'credit_card_id'     => $pending['credit_card_id'],
                'category_id'        => $pending['category_id'],
                'installments_count' => $pending['installments_count'] ?? 1,
            ], $user->id);

            Cache::forget($this->cacheKey($user));

            $valor = '$' . number_format($purchase->total_amount, 0, ',', '.');
            $msg = "✅ **¡Gasto registrado exitosamente!**\n\nGuardé **{$purchase->name}** por **{$valor}**. Tu dashboard ya está actualizado.";
            
            return $isWhatsApp ? $this->formatForWhatsApp($msg) : $msg;

        } catch (\Exception $e) {
            Log::error('[FinTrack AI] Error al guardar compra', ['error' => $e->getMessage()]);
            return "❌ Hubo un error al guardar en la base de datos. Por favor intenta de nuevo o contacta soporte.";
        }
    }

    // =========================================================================
    // GESTIÓN DE CATEGORÍAS (2 Pasos)
    // =========================================================================

    private function handlePrepareCategory(array $args, User $user, bool $isWhatsApp): string
    {
        $name = trim($args['name'] ?? '');
        if (strlen($name) < 2) return "Necesito un nombre para la categoría.";

        Cache::put("fintrack_pending_category_{$user->id}", $args, now()->addMinutes(self::CACHE_TTL_MINUTES));

        $msg = "🛠️ **Vista previa de nueva categoría:**\n\n" .
               "• **Nombre:** {$name}\n" .
               "• **Icono:** " . ($args['icon'] ?? '📁') . "\n" .
               "• **Color:** " . ($args['color'] ?? '#000000') . "\n\n" .
               "¿Confirmas la creación de esta categoría?";

        return $isWhatsApp ? $this->formatForWhatsApp($msg) : $msg;
    }

    private function handleExecuteCategory(User $user, bool $isWhatsApp): string
    {
        $pending = Cache::get("fintrack_pending_category_{$user->id}");
        if (!$pending) return "❌ La sesión expiró. ¿Qué categoría quieres crear?";

        try {
            $category = Category::create([
                'user_id' => $user->id,
                'name'    => $pending['name'],
                'icon'    => $pending['icon']  ?? '📁',
                'color'   => $pending['color'] ?? '#6366f1',
            ]);
            Cache::forget("fintrack_pending_category_{$user->id}");
            $msg = "✅ **Categoría '{$category->name}' creada exitosamente.**";
            return $isWhatsApp ? $this->formatForWhatsApp($msg) : $msg;
        } catch (\Exception $e) {
            Log::error('[FinTrack AI] Error create category', ['error' => $e->getMessage()]);
            return "❌ Error al crear la categoría.";
        }
    }

    // =========================================================================
    // GESTIÓN DE RESPONSABLES (2 Pasos)
    // =========================================================================

    private function handlePrepareResponsible(array $args, User $user, bool $isWhatsApp): string
    {
        $name = trim($args['name'] ?? '');
        if (strlen($name) < 2) return "Necesito el nombre de la persona.";

        Cache::put("fintrack_pending_responsible_{$user->id}", $args, now()->addMinutes(self::CACHE_TTL_MINUTES));

        $msg = "👤 **Vista previa de nuevo responsable:**\n\n" .
               "• **Nombre:** {$name}\n" .
               "• **Email:** " . ($args['email'] ?? 'No especificado') . "\n\n" .
               "¿Confirmas el registro de esta persona?";

        return $isWhatsApp ? $this->formatForWhatsApp($msg) : $msg;
    }

    private function handleExecuteResponsible(User $user, bool $isWhatsApp): string
    {
        $pending = Cache::get("fintrack_pending_responsible_{$user->id}");
        if (!$pending) return "❌ La sesión expiró. ¿A quién quieres registrar?";

        try {
            $person = ResponsiblePerson::create([
                'user_id' => $user->id,
                'name'    => $pending['name'],
                'email'   => $pending['email'] ?? null,
            ]);
            Cache::forget("fintrack_pending_responsible_{$user->id}");
            $msg = "✅ **{$person->name} ha sido registrado(a) como responsable.**";
            return $isWhatsApp ? $this->formatForWhatsApp($msg) : $msg;
        } catch (\Exception $e) {
            Log::error('[FinTrack AI] Error create responsible', ['error' => $e->getMessage()]);
            return "❌ Error al registrar el responsable.";
        }
    }

    // =========================================================================
    // GESTIÓN DE PAGOS (2 Pasos)
    // =========================================================================

    private function handlePreparePayment(array $args, User $user, array $context, bool $isWhatsApp): string
    {
        $cutId = (int) ($args['cut_id'] ?? 0);
        
        // Buscar el corte en los datos del contexto para mayor velocidad
        $cut = null;
        foreach ($context['cards'] as $card) {
            foreach ($card['cuts'] ?? [] as $c) {
                if ($c['id'] === $cutId) {
                    $cut = $c;
                    $cut['card_name'] = $card['name'];
                    break 2;
                }
            }
        }

        if (!$cut) return "No encontré ese periodo de corte. Por favor verifica los datos.";

        $amount = (float) ($args['amount'] ?? $cut['total_accrued']);
        if ($amount <= 0) return "El monto del pago debe ser mayor a cero.";

        $args['amount'] = $amount;
        $args['cut_id'] = $cutId;
        $args['credit_card_id'] = $cut['credit_card_id'];

        Cache::put("fintrack_pending_payment_{$user->id}", $args, now()->addMinutes(self::CACHE_TTL_MINUTES));

        $amountFmt = '$' . number_format($amount, 0, ',', '.');
        $msg = "💳 **Vista previa de pago:**\n\n" .
               "• **Tarjeta:** {$cut['card_name']}\n" .
               "• **Periodo:** " . Carbon::parse($cut['period_end'])->format('M Y') . "\n" .
               "• **Monto a pagar:** {$amountFmt}\n\n" .
               "¿Confirmas este pago?";

        return $isWhatsApp ? $this->formatForWhatsApp($msg) : $msg;
    }

    private function handleExecutePayment(User $user, bool $isWhatsApp): string
    {
        $pending = Cache::get("fintrack_pending_payment_{$user->id}");
        if (!$pending) return "❌ La sesión expiró. ¿Qué pago quieres realizar?";

        try {
            $payment = CardPayment::create([
                'user_id'        => $user->id,
                'credit_card_id' => $pending['credit_card_id'],
                'cut_id'         => $pending['cut_id'],
                'amount'         => $pending['amount'],
                'type'           => 'pago_total',
                'payment_date'   => now(),
            ]);

            // Recalcular el estado del corte
            $cut = Cut::find($pending['cut_id']);
            if ($cut) {
                $this->cutService->recalculateCutTotals($cut);
            }

            Cache::forget("fintrack_pending_payment_{$user->id}");
            
            $msg = "✅ **Pago de $" . number_format($payment->amount, 0, ',', '.') . " registrado exitosamente.**";
            return $isWhatsApp ? $this->formatForWhatsApp($msg) : $msg;
        } catch (\Exception $e) {
            Log::error('[FinTrack AI] Error create payment', ['error' => $e->getMessage()]);
            return "❌ Error al registrar el pago.";
        }
    }

    // =========================================================================
    // RESOLUCIÓN SEMÁNTICA DE CATEGORÍA
    // El LLM ya eligió un ID basándose en los nombres reales del usuario.
    // Aquí solo validamos y aplicamos un fallback si el ID no existe.
    // =========================================================================

    private function resolveCategory(array $args, array $context): array
    {
        $categoryId     = (int) ($args['category_id'] ?? 0);
        $userCategories = collect($context['categories'] ?? []);

        $match = $userCategories->firstWhere('id', $categoryId);

        if ($match) {
            // El LLM acertó — usar tal cual
            $args['category_id']   = $match['id'];
            $args['category_name'] = $match['name'];
            return $args;
        }

        // El LLM devolvió un ID que no existe — loguear y usar la primera disponible
        Log::warning('[FinTrack AI] ID de categoría inválido', [
            'ai_category_id' => $categoryId,
            'available_ids'  => $userCategories->pluck('id')->toArray(),
        ]);

        $fallback = $userCategories->first();
        $args['category_id']   = $fallback['id']   ?? null;
        $args['category_name'] = $fallback['name'] ?? 'Sin categoría';
        // Marcamos baja confianza para mostrar advertencia al usuario
        $args['confidence']    = 'low';

        return $args;
    }

    // =========================================================================
    // RESOLUCIÓN DE TARJETA (validación igual que categoría)
    // =========================================================================

    private function resolveCard(array $args, array $context): array
    {
        $cardId    = (int) ($args['credit_card_id'] ?? 0);
        $userCards = collect($context['cards'] ?? []);

        $match = $userCards->firstWhere('id', $cardId);

        if ($match) {
            $args['credit_card_id']   = $match['id'];
            $args['credit_card_name'] = $args['credit_card_name'] ?? $match['name'];
            return $args;
        }

        Log::warning('[FinTrack AI] ID de tarjeta inválido', [
            'ai_card_id'    => $cardId,
            'available_ids' => $userCards->pluck('id')->toArray(),
        ]);

        $fallback = $userCards->first();
        $args['credit_card_id']   = $fallback['id']   ?? null;
        $args['credit_card_name'] = $fallback['name'] ?? 'Tarjeta principal';
        $args['confidence']       = 'low';

        return $args;
    }

    // =========================================================================
    // CONSTRUCCIÓN DE LA VISTA PREVIA EN MARKDOWN
    // =========================================================================

    private function buildPreviewMarkdown(array $args, float $amount, bool $isWhatsApp): string
    {
        $dateLabel = Carbon::parse($args['purchase_date'])
            ->locale('es')
            ->translatedFormat('j \d\e F \d\e Y');

        $amountFmt    = '$' . number_format($amount, 0, ',', '.');
        $cardName     = $args['credit_card_name'] ?? 'Tarjeta seleccionada';
        $categoryName = $args['category_name']    ?? 'Sin categoría';
        $installments = $args['installments_count'] ?? 1;

        if ($isWhatsApp) {
            $output = "📋 *Vista previa del registro:*\n\n" .
                "🛒 *Descripción:* {$args['name']}\n" .
                "💰 *Valor:* {$amountFmt}\n" .
                "💳 *Tarjeta:* {$cardName}\n" .
                "🏷️ *Categoría:* {$categoryName}\n" .
                "📅 *Fecha:* {$dateLabel}\n" .
                "🔢 *Cuotas:* {$installments}\n\n";

            if (($args['confidence'] ?? 'high') === 'low') {
                $output .= "⚠️ _No estaba del todo seguro de la categoría o la tarjeta. Por favor revísalas antes de confirmar._\n\n";
            }
            $output .= "¿Confirmas el registro? Responde *sí* o corrígeme lo que necesites.";
            return $output;
        }

        $table = "📋 **Vista previa del registro:**\n\n" .
            "| Campo | Valor |\n" .
            "|---|---|\n" .
            "| 🛒 Descripción | **{$args['name']}** |\n" .
            "| 💰 Valor | **{$amountFmt}** |\n" .
            "| 💳 Tarjeta | **{$cardName}** |\n" .
            "| 🏷️ Categoría | **{$categoryName}** |\n" .
            "| 📅 Fecha | **{$dateLabel}** |\n" .
            "| 🔢 Cuotas | **{$installments}** |\n\n";

        // Advertencia de baja confianza en categoría o tarjeta
        if (($args['confidence'] ?? 'high') === 'low') {
            $table .= "> ⚠️ *No estaba del todo seguro de la categoría o la tarjeta. Por favor revísalas antes de confirmar.*\n\n";
        }

        $table .= "¿Confirmas el registro? Responde **sí** o corrígeme lo que necesites.";

        return $table;
    }

    // =========================================================================
    // RECONSTRUCCIÓN DEL HISTORIAL (para multi-turno)
    // Convierte el historial del chat en el formato que espera la API.
    // Los mensajes de "Vista previa" se reconstruyen como tool_call + tool_result
    // para que el modelo entienda el estado de la conversación y no entre en bucles.
    // =========================================================================

    private function reconstructHistory(array $history): array
    {
        $messages = [];

        foreach ($history as $msg) {
            $content = $msg['content'] ?? '';
            $role    = ($msg['role'] ?? 'bot') === 'bot' ? 'assistant' : 'user';

            // Ignorar confirmaciones ya procesadas (✅)
            if (str_contains($content, '✅')) {
                continue;
            }

            // Detectar mensajes de vista previa y reconstruirlos como function call
            // para que el modelo sepa que ya mostró la preview y no la repita
            if ($role === 'assistant' && str_contains($content, 'Vista previa del registro')) {
                $toolCallId = 'call_hist_' . uniqid();

                $messages[] = [
                    'role'    => 'assistant',
                    'content' => null,
                    'tool_calls' => [[
                        'id'   => $toolCallId,
                        'type' => 'function',
                        'function' => [
                            'name'      => 'prepare_purchase',
                            'arguments' => json_encode(['_reconstructed' => true]),
                        ],
                    ]],
                ];

                $messages[] = [
                    'role'         => 'tool',
                    'tool_call_id' => $toolCallId,
                    'content'      => $content,
                ];

                continue;
            }

            $messages[] = ['role' => $role, 'content' => $content];
        }

        return $messages;
    }

    // =========================================================================
    // DEFINICIÓN DE HERRAMIENTAS (Function Calling)
    // =========================================================================

    private function getToolsDefinition(): array
    {
        return [
            [
                'type' => 'function',
                'function' => [
                    'name'        => 'prepare_purchase',
                    'description' => <<<DESC
                    PASO 1 — Genera una vista previa del gasto. 
                    Úsala la primera vez que el usuario mencione un gasto con datos suficientes (nombre + monto + tarjeta).
                    NO la uses si el usuario solo está confirmando algo que ya vio.
                    DESC,
                    'parameters' => [
                        'type'       => 'object',
                        'properties' => [
                            'name' => [
                                'type'        => 'string',
                                'description' => 'Descripción corta del gasto. Ej: "Gasolina moto", "Almuerzo oficina", "Netflix".',
                            ],
                            'total_amount' => [
                                'type'        => 'number',
                                'description' => 'Monto total en pesos colombianos, sin puntos ni símbolos. Ej: 85000',
                            ],
                            'credit_card_id' => [
                                'type'        => 'integer',
                                'description' => 'ID exacto de la tarjeta del listado TARJETAS DISPONIBLES. Busca por nombre, franquicia o últimos 4 dígitos.',
                            ],
                            'credit_card_name' => [
                                'type'        => 'string',
                                'description' => 'Nombre amigable de la tarjeta para mostrar al usuario.',
                            ],
                            'category_id' => [
                                'type'        => 'integer',
                                'description' => 'ID de la categoría del listado CATEGORÍAS DISPONIBLES. Elige semánticamente la que más se acerque al gasto.',
                            ],
                            'category_name' => [
                                'type'        => 'string',
                                'description' => 'Nombre de la categoría elegida (para mostrar al usuario).',
                            ],
                            'installments_count' => [
                                'type'        => 'integer',
                                'description' => 'Número de cuotas. Si no se menciona, usar 1.',
                                'default'     => 1,
                            ],
                            'purchase_date' => [
                                'type'        => 'string',
                                'description' => 'Fecha del gasto en formato YYYY-MM-DD. Usa el año actual si no se especifica. Hoy es: ' . now()->toDateString(),
                            ],
                            'confidence' => [
                                'type'        => 'string',
                                'enum'        => ['high', 'low'],
                                'description' => 'high = estás seguro de la categoría y la tarjeta. low = no hay coincidencia clara y el usuario debería verificar.',
                            ],
                        ],
                        'required' => ['name', 'total_amount', 'credit_card_id', 'category_id', 'confidence'],
                    ],
                ],
            ],
            [
                'type' => 'function',
                'function' => [
                    'name'        => 'create_purchase',
                    'description' => <<<DESC
                    PASO 2 — Guarda el gasto definitivamente en la base de datos.
                    SOLO llámala cuando el usuario haya visto la vista previa Y confirme explícitamente (sí, dale, ok, confirmo, etc.).
                    NUNCA la llames sin que exista una vista previa previa.
                    DESC,
                    'parameters' => [
                        'type'       => 'object',
                        'properties' => (object)[],
                    ],
                ],
            ],
            [
                'type' => 'function',
                'function' => [
                    'name'        => 'prepare_category',
                    'description' => 'PASO 1 — Prepara la creación de una nueva categoría de gastos.',
                    'parameters' => [
                        'type' => 'object',
                        'properties' => [
                            'name'  => ['type' => 'string', 'description' => 'Nombre de la categoría. Ej: "Mascotas", "Hobbies".'],
                            'icon'  => ['type' => 'string', 'description' => 'Emoji representativo. Ej: "🐶", "🎮".'],
                            'color' => ['type' => 'string', 'description' => 'Color hexadecimal. Ej: "#FF5733".'],
                        ],
                        'required' => ['name'],
                    ],
                ],
            ],
            [
                'type' => 'function',
                'function' => [
                    'name'        => 'create_category',
                    'description' => 'PASO 2 — Confirma la creación de la categoría preparada.',
                    'parameters'  => ['type' => 'object', 'properties' => (object)[]],
                ],
            ],
            [
                'type' => 'function',
                'function' => [
                    'name'        => 'prepare_responsible',
                    'description' => 'PASO 1 — Prepara el registro de una nueva persona responsable.',
                    'parameters' => [
                        'type' => 'object',
                        'properties' => [
                            'name'  => ['type' => 'string', 'description' => 'Nombre completo de la persona.'],
                            'email' => ['type' => 'string', 'description' => 'Email (opcional).'],
                        ],
                        'required' => ['name'],
                    ],
                ],
            ],
            [
                'type' => 'function',
                'function' => [
                    'name'        => 'create_responsible',
                    'description' => 'PASO 2 — Confirma el registro de la persona preparada.',
                    'parameters'  => ['type' => 'object', 'properties' => (object)[]],
                ],
            ],
            [
                'type' => 'function',
                'function' => [
                    'name'        => 'prepare_payment',
                    'description' => 'PASO 1 — Prepara el pago de un periodo de corte de una tarjeta.',
                    'parameters' => [
                        'type' => 'object',
                        'properties' => [
                            'cut_id' => ['type' => 'integer', 'description' => 'ID del periodo de corte (obtenido de DEUDAS POR PAGAR).'],
                            'amount' => ['type' => 'number', 'description' => 'Monto a pagar (por defecto el total acumulado).'],
                        ],
                        'required' => ['cut_id'],
                    ],
                ],
            ],
            [
                'type' => 'function',
                'function' => [
                    'name'        => 'create_payment',
                    'description' => 'PASO 2 — Confirma y ejecuta el pago preparado.',
                    'parameters'  => ['type' => 'object', 'properties' => (object)[]],
                ],
            ],
        ];
    }

    // =========================================================================
    // CONSTRUCCIÓN DEL CONTEXTO DEL USUARIO
    // =========================================================================

    private function buildUserContext(User $user): array
    {
        $dashboardItems = $this->summaryService->dashboard($user);

        // Enriquecer con categorías, tarjetas y personas responsables
        $dashboardItems['categories'] = Category::where('user_id', $user->id)
            ->get(['id', 'name', 'icon', 'color'])
            ->toArray();

        $dashboardItems['cards'] = CreditCard::where('user_id', $user->id)
            ->with(['cuts' => fn($q) => $q->where('status', '!=', 'pagado')->orderBy('period_end')])
            ->get()
            ->map(function($card) {
                return [
                    'id'            => $card->id,
                    'name'          => $card->name,
                    'franchise'     => $card->franchise,
                    'last_4_digits' => $card->last_4_digits,
                    'cuts'          => $card->cuts->toArray()
                ];
            })
            ->toArray();

        $dashboardItems['responsibles'] = ResponsiblePerson::where('user_id', $user->id)
            ->get(['id', 'name', 'email'])
            ->toArray();

        return $dashboardItems;
    }

    // =========================================================================
    // CONSTRUCCIÓN DEL SYSTEM PROMPT
    // Toda la "inteligencia de negocio" vive aquí.
    // =========================================================================

    private function buildSystemPrompt(string $userName, array $context): string
    {
        $categories = $context['categories']  ?? [];
        $cards      = $context['cards']       ?? [];
        $resps      = $context['responsibles'] ?? [];

        // Resumen simplificado para el prompt
        $summary = $context;
        unset($summary['categories'], $summary['cards'], $summary['responsibles']);

        $catList  = collect($categories)->map(fn($c) => "  - ID {$c['id']}: \"{$c['name']}\" ({$c['icon']})")->implode("\n");
        $cardList = collect($cards)->map(fn($c) => "  - ID {$c['id']}: \"{$c['name']}\" (*{$c['franchise']}* ends in {$c['last_4_digits']})")->implode("\n");
        $respList = collect($resps)->map(fn($r) => "  - ID {$r['id']}: \"{$r['name']}\"")->implode("\n");

        // Listado detallado de deudas (cortes)
        $debtList = "";
        foreach ($cards as $card) {
            foreach ($card['cuts'] ?? [] as $cut) {
                $amount = '$' . number_format($cut['total_accrued'], 0, ',', '.');
                $debtList .= "  - [CUT ID {$cut['id']}] Tarjeta {$card['name']} | Vence: {$cut['period_end']} | Deuda: {$amount}\n";
            }
        }
        if (!$debtList) $debtList = "  (No hay deudas pendientes en este momento)";

        $financialSummary = json_encode($summary, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
        $today            = now()->toDateString();

        return <<<PROMPT
        Eres FinTrack AI, el asistente financiero personal de {$userName}.
        Responde siempre en Español de Colombia. Tono profesional pero cercano.
        HOY ES: {$today}.

        ══════════════════════════════════════════
        ESTADO FINANCIERO ACTUAL
        ══════════════════════════════════════════
        {$financialSummary}

        DEUDAS POR PAGAR (CORTES):
        {$debtList}

        ══════════════════════════════════════════
        LISTADOS DISPONIBLES
        ══════════════════════════════════════════
        CATEGORÍAS:
        {$catList}

        TARJETAS:
        {$cardList}

        PERSONAS RESPONSABLES:
        {$respList}

        ══════════════════════════════════════════
        REGLAS DE OPERACIÓN (ACCESO TOTAL)
        ══════════════════════════════════════════
        1. GESTIÓN DE GASTOS:
           - Para registrar un gasto: `prepare_purchase` -> Confirmación del usuario -> `create_purchase`.
        
        2. GESTIÓN DE CATEGORÍAS:
           - El usuario puede pedir crear categorías (Ej: "Crea una categoría de Mascotas").
           - Uso: `prepare_category` -> Confirmación -> `create_category`.

        3. GESTIÓN DE RESPONSABLES:
           - El usuario puede agregar personas que le deben dinero o comparten gastos.
           - Uso: `prepare_responsible` -> Confirmación -> `create_responsible`.

        4. GESTIÓN DE PAGOS:
           - El usuario puede pagar sus deudas de tarjeta (cortes).
           - Identifica el CUT ID de la lista "DEUDAS POR PAGAR".
           - Uso: `prepare_payment` -> Confirmación -> `create_payment`.

        ⚠️ REGLA DE ORO DE SEGURIDAD:
        - NUNCA ejecutes una acción de creación o pago sin mostrar primero la VISTA PREVIA y recibir un "SÍ" o confirmación explícita.
        - Si el usuario dice "Paga mi tarjeta Nu", busca el CUT ID más antiguo y prepáralo.

        TIPS DE FORMATO (WHATSAPP):
        - Usa *negrita* para enfatizar valores y nombres.
        - Mantén las respuestas visualmente limpias.
        PROMPT;
    }

    // =========================================================================
    // VISIÓN (análisis de imágenes / recibos)
    // =========================================================================

    private function chatWithVision(array $messages, string $message, array $image, bool $isWhatsApp): string
    {
        // Reemplazar el último mensaje de texto por uno multimodal
        array_pop($messages);

        $messages[] = [
            'role'    => 'user',
            'content' => [
                ['type' => 'text',      'text'      => $message],
                ['type' => 'image_url', 'image_url' => [
                    'url' => 'data:' . $image['mime_type'] . ';base64,' . $image['data'],
                ]],
            ],
        ];

        try {
            $response = Http::withoutVerifying()
                ->withHeaders(['Authorization' => 'Bearer ' . config('services.groq.key')])
                ->post($this->baseUrl, [
                    'model'       => $this->visionModel,
                    'messages'    => $messages,
                    'temperature' => 0.4,
                    'max_tokens'  => 1024,
                ]);

            if ($response->failed()) {
                Log::error('[FinTrack AI] Vision error', ['status' => $response->status()]);
                return "No pude procesar la imagen. ¿Puedes contarme el gasto manualmente?";
            }

            $content = $response->json('choices.0.message.content') ?? '';
            $msg = $content ?: "No pude extraer información de la imagen.";
            return $isWhatsApp ? $this->formatForWhatsApp($msg) : Str::markdown($msg);

        } catch (\Exception $e) {
            Log::error('[FinTrack AI] Excepción en chatWithVision', ['error' => $e->getMessage()]);
            return "Error al analizar la imagen. Por favor intenta de nuevo.";
        }
    }

    // =========================================================================
    // HELPERS PRIVADOS
    // =========================================================================

    private function isConfirmationMessage(string $message): bool
    {
        $lower = mb_strtolower(trim($message));

        // Mensaje muy corto = probablemente una confirmación directa
        if (str_word_count($lower) <= 3) {
            foreach (self::CONFIRM_TRIGGERS as $trigger) {
                if (str_contains($lower, $trigger)) {
                    return true;
                }
            }
        }

        return false;
    }

    private function resolveDate(?string $rawDate): string
    {
        if (!$rawDate) {
            return now()->toDateString();
        }

        try {
            $date        = Carbon::parse($rawDate);
            $currentYear = (int) now()->format('Y');

            // Si el año está desfasado más de 1 año, forzamos el año actual
            if (abs($date->year - $currentYear) > 1) {
                $date->setYear($currentYear);
                // Si aún así queda en el futuro, retrocedemos un año
                if ($date->isFuture()) {
                    $date->subYear();
                }
            }

            return $date->toDateString();
        } catch (\Exception) {
            return now()->toDateString();
        }
    }

    private function cacheKey(User $user): string
    {
        return "fintrack_pending_purchase_{$user->id}";
    }

    private function formatForWhatsApp(string $text): string
    {
        // 1. WhatsApp usa * para negrita en lugar de **
        $text = preg_replace('/\*\*(.*?)\*\*/s', '*$1*', $text);
        
        // 2. Si el LLM devolvió ### o ## para títulos, lo pasamos a negrita simple o lo limpiamos
        $text = preg_replace('/^#+\s+(.*?)$/m', '*$1*', $text);

        // 3. Puedes quitar etiquetas HTML por si acaso el modelo las alucina
        return strip_tags($text);
    }
}